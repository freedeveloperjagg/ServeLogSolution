﻿using Microsoft.Extensions.Configuration;
using ServeLog.Model;
using System;
using System.Configuration;
using System.Data.SqlClient;
using WapiLogger.Models;

namespace ServeLog.Data
{
    /// <summary>
    /// Call the necessary services to Manage the log table
    /// </summary>
    public class LogServices : ILogServices
    {
        private IConfiguration configuration;

        public LogServices(IConfiguration configuration)
        {
            this.configuration = configuration;
        }

        /// <summary>
        /// Write the log in the table. The table is selected by the
        /// value of the appConfig that match with request.Logger
        /// </summary>
        /// <param name="model">
        /// Logger: Must match the AppSetting with the name of the table to  log
        /// or the method fail.
        /// </param>
        public void WriteRecordInLog(LoggerModel model)
        {
            // Call conection string
            var connString = configuration.GetConnectionString("SpiritLoggerDb");

            // Get the specific table to be logged
            Settings.LogTables.TryGetValue(model.Logger, out string table);
            if (string.IsNullOrWhiteSpace(table))
            {
                throw new ApplicationException($"The used token is not a valid token: {model.Logger}");
            }

            this.InsertingLogRecord(model, connString, table);
        }

        public void InsertingLogRecord(LoggerModel model, string connString, string table)
        {
            // Sanitarize Model
            model.Message = model.Message.Length > 3999 ? model.Message.Remove(3998) : model.Message;
            model.Exception = (model.Exception != null)
                ? model.Exception.Length > 1999 ? model.Exception.Remove(1998) : model.Exception
                : string.Empty;
            model.MachineName = model.MachineName.Length > 254 ? model.MachineName.Remove(253) : model.MachineName;
            model.Level = model.Level.Length > 49 ? model.Level.Remove(48) : model.Level;
            model.Logger = model.Logger.Length > 254 ? model.Logger.Remove(253) : model.Logger;

            // Prepare query
            var sql = $@"INSERT INTO {table} 
                        ([Date],[Thread],[Level],[Logger],[Message],[Exception])
                        VALUES
                        (
                        @Date,
                        @Thread,
                        @Level,
                        @Logger,
                        @Message,
                        @Exception
                        )";
            var conn = new SqlConnection(connString);
            var command = new SqlCommand(sql, conn);
            command.Parameters.AddWithValue("@Date", model.Date);
            command.Parameters.AddWithValue("@Thread", model.MachineName);
            command.Parameters.AddWithValue("@Level", model.Level);
            command.Parameters.AddWithValue("@Logger", model.Logger);
            command.Parameters.AddWithValue("@Message", model.Message);
            command.Parameters.AddWithValue("@Exception", model.Exception);
            // Open The connexion...
            conn.Open();
            try
            {
                var result = command.ExecuteNonQuery();
                ////Log.Debug("Log was wrote");
            }
            finally
            {
                conn.Close();
            }
        }
    }
}