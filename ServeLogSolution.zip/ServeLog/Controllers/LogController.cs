﻿using System;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using ServeLog.Models;
using ServeLog.Bo;
using ServeLog.Infrastructure;
using System.Net;

namespace ServeLog.Controllers
{
    /// <summary>
    /// The Logger Controller
    /// </summary>
    [Route("[controller]")]
    public class LogController :  ControllerBase
    {
        private ILogBo bo { get; }
        private IInternalLog log { get; }

        public LogController(ILogBo bo, IInternalLog log)
        {
            this.bo = bo;
            this.log = log;
        }
        
        /// <summary>
        /// Simple method to test if the log is alive
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public IActionResult GetAlive()
        {
            return Ok("Logger is alive 1");
        }

        /// <summary>
        /// Enter the info in the log.
        /// if error return a http 500 internal server error 
        /// and a HttpError based in the exception information
        /// </summary>
        /// <param name="request">
        /// The information to be logged
        /// </param>
        /// <returns>null is ok</returns>
        /// <exception cref="HttpError">If error return a httpError Class</exception>
        [HttpPost("LogEntryAsync")]
        public async Task<ActionResult> PostLogEntryAsync([FromBody] LogRequest request)
        {
            try
            {
                await bo.PostLogEntryAsync(request);
                return Ok();
            }
            catch (ApplicationException ex)
            {
                log.WriteErrorLog("Application Exception in PostLogEntryAsync", ex.Message);
                return BadRequest(ex);
            }
            catch (Exception ex)
            {
                log.WriteErrorLog("Exception Raised", ex.Message);
                return StatusCode((int)HttpStatusCode.InternalServerError, ex);
            }
        }
    }
}
