﻿namespace ServeLog.Infrastructure
{
    public interface IInternalLog
    {
        void WriteDebugLog(string message, string exception = "");
        void WriteErrorLog(string message, string exception = "");
        void WriteFatalLog(string message, string exception = "");
        void WriteInfoLog(string message, string exception = "");
        void WriteWarnLog(string message, string exception = "");
    }
}