﻿using ServeLog.Data;
using ServeLog.Model;
using System;
using WapiLogger.Models;

namespace ServeLog.Infrastructure
{
    public class InternalLog : IInternalLog
    {
        private string connectionString { get; }
        private ILogServices service { get; }


        public InternalLog(ILogServices service)
        {
            connectionString = Settings.InternalLog.ConnectionString;
            this.service = service;
        }

        /// <summary>
        /// Write FATAL Log
        /// </summary>
        /// <param name="message"></param>
        /// <param name="exception"></param>
        public void WriteFatalLog(string message, string exception = "")
        {
            // Set Level
            if (Settings.InternalLog.LogLevel == LogLevelEnum.NONE) { return; }

            // Create log object
            LoggerModel log = new LoggerModel()
            {
                Date = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, Settings.TimeZone),
                Level = "FATAL",
                MachineName = Environment.MachineName,
                Logger = "Serve Logger",
                Message = message,
                Exception = exception
            };

            service.InsertingLogRecord(log, this.connectionString, Settings.InternalLog.Table);
        }

        /// <summary>
        /// Write Error Log
        /// </summary>
        /// <param name="message"></param>
        /// <param name="exception"></param>
        public void WriteErrorLog(string message, string exception = "")
        {
            if ((int)Settings.InternalLog.LogLevel < 4) { return; }

            // Create log object
            LoggerModel log = new LoggerModel()
            {
                Date = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, Settings.TimeZone),
                Level = "ERROR",
                MachineName = Environment.MachineName,
                Logger = "Serve Logger",
                Message = message,
                Exception = exception
            };

            service.InsertingLogRecord(log, this.connectionString, Settings.InternalLog.Table);
        }

        /// <summary>
        /// Write WARN Log
        /// </summary>
        /// <param name="message"></param>
        /// <param name="exception"></param>
        public void WriteWarnLog(string message, string exception = "")
        {
            if ((int)Settings.InternalLog.LogLevel < 3) { return; }

            // Create log object
            LoggerModel log = new LoggerModel()
            {
                Date = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, Settings.TimeZone),
                Level = "WARN",
                MachineName = Environment.MachineName,
                Logger = "Serve Logger",
                Message = message,
                Exception = exception
            };

            service.InsertingLogRecord(log, this.connectionString, Settings.InternalLog.Table);
        }

        /// <summary>
        /// Write INFO Log
        /// </summary>
        /// <param name="message"></param>
        /// <param name="exception"></param>
        public void WriteInfoLog(string message, string exception = "")
        {
            if ((int)Settings.InternalLog.LogLevel < 2) { return; }
            // Create log object
            LoggerModel log = new LoggerModel()
            {
                Date = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, Settings.TimeZone),
                Level = "INFO",
                MachineName = Environment.MachineName,
                Logger = "Serve Logger",
                Message = message,
                Exception = exception
            };

            service.InsertingLogRecord(log, this.connectionString, Settings.InternalLog.Table);

        }

        /// <summary>
        /// Write DEBUG LOG
        /// </summary>
        /// <param name="message"></param>
        /// <param name="exception"></param>
        public void WriteDebugLog(string message, string exception = "")
        {
            if ((int)Settings.InternalLog.LogLevel < 1) { return; }

            // Create log object
            LoggerModel log = new LoggerModel()
            {
                Date = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, Settings.TimeZone),
                Level = "DEBUG",
                MachineName = Environment.MachineName,
                Logger = "Serve Logger",
                Message = message,
                Exception = exception
            };

            service.InsertingLogRecord(log, this.connectionString, Settings.InternalLog.Table);
        }
    }
}
