﻿using System;
using System.ComponentModel.DataAnnotations;

namespace ServeLog.Models
{
    /// <summary>
    /// The Log Request Class
    /// </summary>
    public class LogRequest
    {
        /// <summary>
        /// Used to link the error to the user with the log 
        /// logged
        /// </summary>
        public DateTime CreatedDate { get; set; }
        
        /// <summary>
        /// The name of the machine where log is emitted
        /// </summary>
        [Required]
        public string MachineName { get; set; }

        /// <summary>
        /// The register Level
        /// </summary>
        [Required]
        public string Level { get; set; }

        /// <summary>
        /// The name of the logger
        /// Don't touch this!! this name is used to localize the log table.
        /// </summary>
        [Required]
        public string Logger { get; set; }

        /// <summary>
        /// The message to be show
        /// </summary>
        [Required]
        public string Message { get; set; }

        /// <summary>
        /// The exception Message to be logged
        /// </summary>
        public string Exception { get; set; }
    }
}