﻿
using System;
using System.Net;

namespace ServeLog.Model
{
    public class ErrorRespose
    {
        /// <summary>
        /// This link the log record with the error 
        /// message
        /// </summary>
        public DateTime DateCreated { get; set; }

        /// <summary>
        /// Used to send a code response for errors
        /// type 400.
         /// </summary>
        public string ActionCode { get; set; }
        
        /// <summary>
        /// Friendly description, 
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// This object get extra information. 
        /// Must be empty in production
        /// </summary>
        public ErrorInformation[] DebugInformation { get; set; }
    }

    public class ErrorInformation
    {
        public int Code { get; set; }

        public string Description { get; set; }
    }
}
