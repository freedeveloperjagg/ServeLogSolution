using HealthChecks.UI.Client;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using Servelog.Infrastructure.HealthCheck;
using ServeLog.Bo;
using ServeLog.Data;
using ServeLog.Infrastructure;
using ServeLog.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ServeLog
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "ServeLog", Version = "v1" });
            });

            // Get Settings
            this.GetSettings();

            services.AddSingleton(Configuration);

            // Add HealthCheck Infrastructure
            services.AddHealthChecks()
                .AddCheck<MemoryHealthCheck>("Memory")
                ////.AddCheck<SystemMemoryHealthCheck>("System-Memory")
                .AddCheck<VersionHealthCheck>("Version")
                .AddCheck<DataBaseHealthCheck>("Database");

            // Configure HealthCheck
            // Configure Code Injection
            services.AddScoped<ILogServices, LogServices>();
            services.AddScoped<IInternalLog, InternalLog>();
            services.AddScoped<ILogBo, LogBo>();
        }


        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseSwagger();
                app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "ServeLog v1"));
            }

            app.UseHealthChecks("/health"
               , new Microsoft.AspNetCore.Diagnostics.HealthChecks.HealthCheckOptions()
               {
                   Predicate = _ => true,
                   ResponseWriter = UIResponseWriter.WriteHealthCheckUIResponse
               }
            );


            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }

        /// <summary>
        /// Get application Settings
        /// </summary>
        private void GetSettings()
        {
            // Get settings..................................................................
            Settings.LogTables = Configuration.GetSection("Tables").Get<Dictionary<string, string>>();
            Settings.InternalLog = new InternalLogSettings();
            Settings.InternalLog.Table = Configuration["InternalLogSettings:Table"];
            bool valid = Enum.TryParse(Configuration["InternalLogSettings:LogLevel"], true, out LogLevelEnum result);
            Settings.InternalLog.LogLevel = valid ? result : LogLevelEnum.INFO;

            // Get Log Zone Time to be used
            var timeZone = Configuration["TimeZone"];
            Settings.TimeZone = timeZone == null
                ? TimeZoneInfo.Utc
                : TimeZoneInfo.FindSystemTimeZoneById(timeZone);

            // Get the cancellation await token
            Settings.TaskCancellationTimeMs = Convert.ToInt32(Configuration["TaskCancellationTimeMs"]);

            // Get if we use the internal datetime or we priorize the DateTime sent in the log
            Settings.UseInternalDateTime = Convert.ToBoolean(Configuration["UseInternalDateTime"]);
            // End Settings ..................................................................
        }
    }
}
